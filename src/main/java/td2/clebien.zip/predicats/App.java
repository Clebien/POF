package td2.predicats;

import java.util.function.Predicate;

public class App {

    public static void question1(){
        Paire<Integer,Double> client1 = new Paire<>(145,180);
        Paire<Integer,Double> client2 = new Paire<>(96,125);

        Predicate<Paire<Integer,Double> tropPetit = x -> x.fst < 100;
        tropPetit.test(client1);

        Predicate<Paire<Integer,Double> tropGrand = x -> x.fst > 200;
        tropGrand.test(client2);

        Predicate<Paire<Integer,Double>  tailleIncorrect = tropPetit.or(tropGrand);
        tailleIncorrect.test(client1);

        Predicate <Paire<Integer,Integer>> tailleCorrecte = tropGrand.negate().and(tropPetit.negate());
        tailleCorrecte.test(client1);

        Predicate<Paire<Integer,Double> tropLourd = x -> x.snd < 150.0;
        tropLourd.test(client1);

        Predicate<Paire<Integer,Double> poidsAutorise = negate(tropLourd);
        tropLourd.test(client1);

    }

    public static void main(String[] args){
        App.question1();
    }
}
